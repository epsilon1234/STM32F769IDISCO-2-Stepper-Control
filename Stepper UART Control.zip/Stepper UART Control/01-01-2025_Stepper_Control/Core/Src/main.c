/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f7xx.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    uint8_t header;     // Start byte
    uint8_t dir1;       // Motor 1 direction
    uint32_t steps1;    // Motor 1 steps
    uint8_t dir2;       // Motor 2 direction
    uint32_t steps2;    // Motor 2 steps
    uint16_t speed;     // Shared speed in RPM
    uint8_t checksum;   // Checksum
    uint8_t end_byte;   // End byte
} Telecommand_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PACKET_SIZE 15
#define AF02 0x02
#define __DIR_CW 1
#define __DIR_CCW 0

#define __PA12_HIGH GPIOA->BSRR = GPIO_BSRR_BS12 // Motor 1 DIR CCW
#define __PA12_LOW GPIOA->BSRR = GPIO_BSRR_BR12 // Motor 1 DIR CW
#define __PA4_HIGH GPIOA->BSRR = GPIO_BSRR_BS4 // Motor 2 DIR CCW
#define __PA4_LOW GPIOA->BSRR = GPIO_BSRR_BR4 // Motor 2 DIR CW

#define __PB13_HIGH GPIOB->BSRR = GPIO_BSRR_BS14 // Motor 1 Disable
#define __PB13_LOW GPIOB->BSRR = GPIO_BSRR_BR14 // Motor 1 Enable
#define __PC_HIGH GPIOC->BSRR = GPIO_BSRR_BS2 // Motor 2 Disable
#define __PC_LOW GPIOC->BSRR = GPIO_BSRR_BR2 // Motor 2 Enable

#define TELEMETRY_START_BYTE  0xBB
#define TELEMETRY_END_BYTE    0xEE
#define TELECOMMAND_HEADER    0xAA
#define TELECOMMAND_END_BYTE  0x55

#define TELEMETRY_SIZE 9
#define TELECOMMAND_SIZE 15
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
void send_telemetry(uint8_t motor_id, uint8_t direction, uint32_t current_steps);
uint8_t calculate_checksum(uint8_t *data, uint8_t length);
void process_telecommand(void);
void stepper_init(void);
void stepper1_start(uint16_t Pulse, uint8_t DIR);
void stepper2_start(uint16_t Pulse, uint8_t DIR);
void stepper1_finish(void);
void stepper2_finish(void);
void stepper_finish(void);
void update_stepper_speed(uint8_t stepper, uint32_t speed);
void delay_ms(uint32_t ms);
void LimitSwitch1_Triggered(void);
void LimitSwitch2_Triggered(void);
void LimitSwitch3_Triggered(void);
void LimitSwitch4_Triggered(void);
void LimitSwitch1_Released(void);
void LimitSwitch2_Released(void);
void LimitSwitch3_Released(void);
void LimitSwitch4_Released(void);
void GPIO_LimitSwitch_Init(void);
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
// Flag to indicate data reception
uint8_t DIR=0;
volatile uint32_t systick_counter = 0;
volatile uint32_t debounce_time = 0;
uint8_t telemetry_buffer[TELEMETRY_SIZE];
uint8_t telecommand_buffer[TELECOMMAND_SIZE];

uint32_t target_pulses1 = 0;  // Total pulses for Stepper 1
uint32_t target_pulses2 = 0;  // Total pulses for Stepper 2
uint32_t accel_pulses = 2000;     // Pulses for acceleration
uint32_t decel_pulses = 2000;     // Pulses for deceleration
uint32_t current_pulses1 = 0;     // Completed pulses for Stepper 1
uint32_t current_pulses2 = 0;     // Completed pulses for Stepper 2
uint32_t speed1 = 1000;           // Initial speed for Stepper 1 (in Hz)
uint32_t speed2 = 1000;           // Initial speed for Stepper 2 (in Hz)
uint32_t max_speed = 30000;       // Maximum speed for both steppers (in Hz)

uint8_t m1_dir=0;
uint8_t m2_dir=0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART6_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  GPIO_LimitSwitch_Init();  // Initialize GPIO for limit switches
  stepper_init();           // Initialize stepper motors

//  uint32_t target_pulses1 = 32000;  // Total pulses for Stepper 1
//  uint32_t target_pulses2 = 32000;  // Total pulses for Stepper 2
//  uint32_t accel_pulses = 2000;     // Pulses for acceleration
//  uint32_t decel_pulses = 2000;     // Pulses for deceleration
//  uint32_t current_pulses1 = 0;     // Completed pulses for Stepper 1
//  uint32_t current_pulses2 = 0;     // Completed pulses for Stepper 2
//  uint32_t speed1 = 1000;           // Initial speed for Stepper 1 (in Hz)
//  uint32_t speed2 = 1000;           // Initial speed for Stepper 2 (in Hz)
//  uint32_t max_speed = 30000;       // Maximum speed for both steppers (in Hz)

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart6, telecommand_buffer, TELECOMMAND_SIZE);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
      current_pulses1 = target_pulses1 - TIM1->CNT;
      current_pulses2 = target_pulses2 - TIM2->CNT;

      /* Telemetry transmission */
      send_telemetry(1, m1_dir, current_pulses1);
      send_telemetry(2, m2_dir, current_pulses2);

      /* Acceleration and Deceleration logic */
      if (current_pulses1 < accel_pulses)
          speed1 = 1000 + (max_speed - 1000) * current_pulses1 / accel_pulses;
      else if (current_pulses1 > (target_pulses1 - decel_pulses))
          speed1 = 1000 + (max_speed - 1000) * (target_pulses1 - current_pulses1) / decel_pulses;
      else
          speed1 = max_speed;
      update_stepper_speed(1, speed1);
//      send_telemetry(1, m1_dir, current_pulses1);

      if (current_pulses2 < accel_pulses)
          speed2 = 1000 + (max_speed - 1000) * current_pulses2 / accel_pulses;
      else if (current_pulses2 > (target_pulses2 - decel_pulses))
          speed2 = 1000 + (max_speed - 1000) * (target_pulses2 - current_pulses2) / decel_pulses;
      else
          speed2 = max_speed;
      update_stepper_speed(2, speed2);
//      send_telemetry(2, m2_dir, current_pulses2);
    /* USER CODE BEGIN */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 216;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  huart6.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart6.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void send_telemetry(uint8_t motor_id, uint8_t direction, uint32_t current_steps)
{
    telemetry_buffer[0] = TELEMETRY_START_BYTE;
    telemetry_buffer[1] = motor_id;
    telemetry_buffer[2] = direction;
    telemetry_buffer[3] = (current_steps >> 24) & 0xFF;
    telemetry_buffer[4] = (current_steps >> 16) & 0xFF;
    telemetry_buffer[5] = (current_steps >> 8) & 0xFF;
    telemetry_buffer[6] = current_steps & 0xFF;
    telemetry_buffer[7] = calculate_checksum(telemetry_buffer, TELEMETRY_SIZE - 2);
    telemetry_buffer[8] = TELEMETRY_END_BYTE;

    HAL_UART_Transmit_IT(&huart6, telemetry_buffer, TELEMETRY_SIZE);
}

/* Calculate checksum */
uint8_t calculate_checksum(uint8_t *data, uint8_t length)
{
    uint8_t checksum = 0;
    for (uint8_t i = 0; i < length; i++)
        checksum ^= data[i];
    return checksum;
}

/* Telecommand processing */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART6)
    {
        process_telecommand();
        HAL_UART_Receive_IT(&huart6, telecommand_buffer, TELECOMMAND_SIZE);
    }
}

void process_telecommand(void)
{
    if (telecommand_buffer[0] != TELECOMMAND_HEADER || telecommand_buffer[TELECOMMAND_SIZE - 1] != TELECOMMAND_END_BYTE)
        return;

    uint8_t checksum = calculate_checksum(telecommand_buffer, TELECOMMAND_SIZE - 2);
    if (checksum != telecommand_buffer[TELECOMMAND_SIZE - 2])
        return;

    uint8_t dir1 = telecommand_buffer[1];
    uint32_t steps1 = (telecommand_buffer[2] << 24) | (telecommand_buffer[3] << 16) | (telecommand_buffer[4] << 8) | telecommand_buffer[5];
    uint8_t dir2 = telecommand_buffer[6];
    uint32_t steps2 = (telecommand_buffer[7] << 24) | (telecommand_buffer[8] << 16) | (telecommand_buffer[9] << 8) | telecommand_buffer[10];
    uint32_t speed = (telecommand_buffer[11] << 8) | telecommand_buffer[12];

    target_pulses1=steps1;
    target_pulses2=steps2;
    speed1=speed;
    speed2=speed;
    m1_dir=dir1;
    m2_dir=dir2;


    stepper1_start(steps1, dir1);
    stepper2_start(steps2, dir2);
    update_stepper_speed(1, speed);
    update_stepper_speed(2, speed);
}

void update_stepper_speed(uint8_t stepper, uint32_t speed)
{
    // Assuming a 108 MHz clock
    uint32_t system_clock = 108000000U;
    uint32_t prescaler = (system_clock / speed) - 1;
    // If prescaler is 0, set to a default value like 3000
    if (prescaler == 0) {
        prescaler = 3000;
    }
    // Ensure the prescaler is within the valid range (max prescaler is 65535)
    if (prescaler > 65535) {
        prescaler = 65535;  // Set to max if it's too large
    }
    if (stepper == 1)
    {
        TIM3->PSC = prescaler;     // Set prescaler for Stepper 1 (PWM generation on TIM3)
    }
    else if (stepper == 2)
    {
        TIM4->PSC = prescaler;     // Set prescaler for Stepper 2 (PWM generation on TIM4)
    }
}

void stepper1_stop(void) {
    TIM3->CR1 &= ~TIM_CR1_CEN;
}

void stepper2_stop(void) {
    TIM4->CR1 &= ~TIM_CR1_CEN;
}

void stepper1_start(uint16_t Pulse, uint8_t DIR) {
    uint8_t Q = Pulse / 65536;
    uint16_t R = Pulse % 65536;

    TIM1->DIER &= ~TIM_DIER_UIE;

    if (DIR == __DIR_CW) {
        __PA12_HIGH;
    } else {
        __PA12_LOW;
    }

    if (R == 0) {
        R = 65536;
        Q = Q - 1;
    }

    TIM1->RCR = Q;
    TIM1->EGR = TIM_EGR_UG;
    TIM1->CNT = R ;
    TIM1->SR = ~TIM_SR_UIF;
    TIM1->DIER |= TIM_DIER_UIE;

    TIM3->CR1 |= TIM_CR1_CEN;
    TIM1->CR1 |= TIM_CR1_CEN;
}

void stepper2_start(uint16_t Pulse, uint8_t DIR) {
    uint8_t Q = Pulse / 65536;
    uint16_t R = Pulse % 65536;

    if (DIR == __DIR_CW) {
        __PA4_HIGH;
    } else {
        __PA4_LOW;
    }

    TIM2->DIER &= ~TIM_DIER_UIE;

    if (R == 0) {
        R = 65536;
        Q = Q - 1;
    }

    TIM2->RCR = Q;
    TIM2->EGR = TIM_EGR_UG;
    TIM2->CNT = R ;
    TIM2->SR = ~TIM_SR_UIF;
    TIM2->DIER |= TIM_DIER_UIE;

    TIM4->CR1 |= TIM_CR1_CEN;
    TIM2->CR1 |= TIM_CR1_CEN;
}
void stepper1_finish(void) {
    stepper1_stop();
}

void stepper2_finish(void) {
    stepper2_stop();
}


void stepper_init(void) {
    // Enable GPIOB clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    // Enable GPIOB clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

    // Stepper 1 Direction Pin
    GPIOA->MODER &= ~GPIO_MODER_MODER4;
    GPIOA->MODER |= GPIO_MODER_MODER4_0;

    // Stepper 2 Direction Pin
    GPIOA->MODER &= ~GPIO_MODER_MODER12;
    GPIOA->MODER |= GPIO_MODER_MODER12_0;

    // Stepper 1 Enable Pin
    GPIOB->MODER &= ~GPIO_MODER_MODER14;
    GPIOB->MODER |= GPIO_MODER_MODER14_0;

    // Stepper 2 Enable Pin
    GPIOC->MODER &= ~GPIO_MODER_MODER2;
    GPIOC->MODER |= GPIO_MODER_MODER2_0;

    // Configure PA6 as alternate function (AF02 for TIM3_CH1)
    GPIOA->MODER &= ~GPIO_MODER_MODER6;  // Clear mode bits for PA6
    GPIOA->MODER |= GPIO_MODER_MODER6_1; // Set to alternate function mode
    GPIOA->AFR[0] |= (AF02 << (4 * 6));  // Set AF02 for PA6 (TIM3_CH1)

    // Configure PB8 as alternate function (AF02 for TIM4_CH3)
    GPIOB->MODER &= ~GPIO_MODER_MODER8;
    GPIOB->MODER |= GPIO_MODER_MODER8_1; // Alternate function mode
    GPIOB->AFR[1] |= (AF02 << ((8 - 8) * 4)); // AF02 for TIM4_CH3

    // Enable TIM3 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // Enable TIM4 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

    // Reset and configure TIM3
    TIM3->CR1 = 0x00;              // Reset control register
    TIM3->PSC = 3000U;            // Prescaler for desired frequency
    TIM3->ARR = 1U;                // Auto-reload value
    TIM3->CCR1 = 1U;               // 50% duty cycle for PWM

    // Reset and configure TIM4
    TIM4->CR1 = 0x00;              // Reset control register
    TIM4->PSC = 3000U;             // Prescaler for desired frequency
    TIM4->ARR = 1U;             // Auto-reload value
    TIM4->CCR3 = 1U;             // 50% duty cycle for PWM

    // Configure TIM3 Channel 1 as PWM mode 1
    TIM3->CCMR1 &= ~TIM_CCMR1_CC1S; // Clear input capture bits
    TIM3->CCMR1 |= TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2; // Set PWM mode 1
    TIM3->CCMR1 |= TIM_CCMR1_OC1PE; // Enable output preload

    // Configure TIM4 Channel 3 as PWM mode 1
    TIM4->CCMR2 &= ~TIM_CCMR2_CC3S; // Clear input capture bits
    TIM4->CCMR2 |= TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2; // Set PWM mode 1
    TIM4->CCMR2 |= TIM_CCMR2_OC3PE; // Enable output preload

    // Enable TIM3 Channel 1 output
    TIM3->CCER &= ~TIM_CCER_CC1P;  // Active high polarity
    TIM3->CCER |= TIM_CCER_CC1E;   // Enable output

    // Enable TIM4 Channel 3 output
    TIM4->CCER &= ~TIM_CCER_CC3P;  // Active high polarity
    TIM4->CCER |= TIM_CCER_CC3E;   // Enable output

    // TIM1 Init
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    TIM1->CR1 &= ~TIM_CR1_CMS;

    //TIM2 Init
    RCC->APB1ENR |=RCC_APB1ENR_TIM2EN;

    TIM2->CR1 &= ~TIM_CR1_CMS;

    // Enable the TIM1 clock in APB2
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Enable the TIM1 clock in APB2
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    // Configure counter mode for TIM1: Edge-aligned, up-counting, one-pulse mode
    TIM1->CR1 &= ~TIM_CR1_CMS;          // Clear CMS bits (edge-aligned mode)
    TIM1->CR1 |= TIM_CR1_DIR;           // Set DIR for down-counting
    TIM1->CR1 |= TIM_CR1_OPM;           // Enable one-pulse mode

    // Configure counter mode for TIM2: Edge-aligned, up-counting, one-pulse mode
    TIM2->CR1 &= ~TIM_CR1_CMS;          // Clear CMS bits (edge-aligned mode)
    TIM2->CR1 |= TIM_CR1_DIR;           // Set DIR for down-counting
    TIM2->CR1 |= TIM_CR1_OPM;           // Enable one-pulse mode

    // Set TIM1 prescaler and auto-reload value
    TIM1->PSC = 0;                      // No prescaler
    TIM1->ARR = 65535;                  // Set auto-reload value to maximum

    // Set TIM2 prescaler and auto-reload value
    TIM2->PSC = 0;                      // No prescaler
    TIM2->ARR = 65535;                  // Set auto-reload value to maximum

    // Configure TIM3 as the master mode trigger
    TIM3->CR2 &= ~TIM_CR2_MMS;          // Clear MMS bits
    TIM3->CR2 |= TIM_CR2_MMS_1;         // Set update event as TRGO (Master Mode Selection)

    // Configure TIM4 as the master mode trigger
    TIM4->CR2 &= ~TIM_CR2_MMS;          // Clear MMS bits
    TIM4->CR2 |= TIM_CR2_MMS_1;         // Set update event as TRGO (Master Mode Selection)

    // Configure TIM1 as a slave, triggered by TIM3
    TIM1->SMCR &= ~TIM_SMCR_TS;         // Clear TS bits
    TIM1->SMCR |= TIM_SMCR_TS_1 ; // Set ITR2 (TIM3 trigger) as the trigger input
    TIM1->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_1 | TIM_SMCR_SMS_0); // Configure SMS for trigger mode

    // Configure TIM2 as a slave, triggered by TIM4
    TIM2->SMCR &= ~TIM_SMCR_TS;         // Clear TS bits
    TIM2->SMCR |= (TIM_SMCR_TS_1|TIM_SMCR_TS_0) ; // Set ITR3 (TIM2 trigger) as the trigger input
    TIM2->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_1 | TIM_SMCR_SMS_0); // Configure SMS for trigger mode

    // Second Master (T1) and Slave (T3) relationship

    // TIM1 Master TGRO
    TIM1->CR2 &= ~TIM_CR2_MMS;
    TIM1->CR2 |= TIM_CR2_MMS_0;


    // TIM2 Master TGRO
    TIM2->CR2 &= ~TIM_CR2_MMS;
    TIM2->CR2 |= TIM_CR2_MMS_0;

    // TIM3 Slave Trigger from TIM1 ITR0
    TIM3->SMCR &= ~TIM_SMCR_TS;

    //TIM4 Slave Trigger from TIM2 ITR1
    TIM4->SMCR &= ~TIM_SMCR_TS;
    TIM4->SMCR |= TIM_SMCR_TS_0;

    // TIM3 Slave Gated mode SMS
    TIM3->SMCR &= ~TIM_SMCR_SMS;
    TIM3->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_0);

    //TIM4 Slave Gated mode SMS
    TIM4->SMCR &=~TIM_SMCR_SMS;
    TIM4->SMCR |= (TIM_SMCR_SMS_2|TIM_SMCR_SMS_0);

    // TIM1 update interrupt
    TIM1->SR = ~TIM_SR_UIF;
    TIM1->DIER |= TIM_DIER_UIE;

    //TIM2 update interrupt
    TIM2->SR = ~TIM_SR_UIF;
    TIM2->DIER |= TIM_DIER_UIE;

    NVIC_SetPriority(TIM1_UP_TIM10_IRQn, NVIC_EncodePriority(0, 9, 0));
    NVIC_EnableIRQ(TIM1_UP_TIM10_IRQn);
    NVIC_SetPriority(TIM2_IRQn, NVIC_EncodePriority(0, 9, 0));
    NVIC_EnableIRQ(TIM2_IRQn);
}

void TIM1_UP_TIM10_IRQHandler(void) {
    if (TIM1->SR & TIM_SR_UIF) {
        TIM1->SR &= ~TIM_SR_UIF;
        stepper1_finish();
    }
}

void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR &= ~TIM_SR_UIF;
        stepper2_finish();
    }
}
__weak void SysTick_Handler(void)
{
  HAL_IncTick();      // Increment HAL's tick (for compatibility)
  systick_counter++;  // Increment custom counter
}

/* Function to implement non-blocking delay */
void delay_ms(uint32_t ms)
{
  uint32_t start_time = systick_counter;
  while ((systick_counter - start_time) < ms)
  {
    // Wait for the desired duration
  }
}

void GPIO_LimitSwitch_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Enable GPIO Clocks
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOJ_CLK_ENABLE();

    // Configure PF10 (Limit Switch 1 Input) as interrupt
    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;  // or IT_FALLING, depending on behavior
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    // Configure PF7 (Limit Switch 2 Input) as interrupt
    GPIO_InitStruct.Pin = GPIO_PIN_7;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    // Configure PB15 (Limit Switch 3 Input) as interrupt
    GPIO_InitStruct.Pin = GPIO_PIN_15;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Configure PH6 (Limit Switch 4 Input) as interrupt
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

    // Configure PF8 (Limit Switch 1 Output) as constantly pulled-up
    GPIO_InitStruct.Pin = GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    // Configure PA11 (Limit Switch 3 Output) as constantly pulled-up
    GPIO_InitStruct.Pin = GPIO_PIN_11;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    // Configure PJ4 (Limit Switch 4 Output) as constantly pulled-up
    GPIO_InitStruct.Pin = GPIO_PIN_4;
    HAL_GPIO_Init(GPIOJ, &GPIO_InitStruct);

    // Set initial output state
    HAL_GPIO_WritePin(GPIOF, GPIO_PIN_8, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOJ, GPIO_PIN_4, GPIO_PIN_SET);

    // Enable and set EXTI interrupt priority
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 2, 0);  // For PF10 and PB15
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

    HAL_NVIC_SetPriority(EXTI9_5_IRQn, 2, 0);  // For PF7 and PH6
    HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}

void Handle_EXTI_Interrupt(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint32_t* debounce_time,
                           void (*Triggered)(), void (*Released)(), uint32_t debounce_delay) {
    if (__HAL_GPIO_EXTI_GET_IT(GPIO_Pin)) {
        __HAL_GPIO_EXTI_CLEAR_IT(GPIO_Pin);

        // Debounce logic
        if (HAL_GetTick() - *debounce_time > debounce_delay) {
            *debounce_time = HAL_GetTick();

            // Check current state of the pin
            if (HAL_GPIO_ReadPin(GPIOx, GPIO_Pin) == GPIO_PIN_SET) {
                Released();
            } else {
                Triggered();
            }
        }
    }
}

void EXTI15_10_IRQHandler(void) {
    static uint32_t debounce_time_10 = 0;
    static uint32_t debounce_time_15 = 0;

    Handle_EXTI_Interrupt(GPIOF, GPIO_PIN_10, &debounce_time_10,
                          LimitSwitch1_Triggered, LimitSwitch1_Released, 10);

    Handle_EXTI_Interrupt(GPIOB, GPIO_PIN_15, &debounce_time_15,
                          LimitSwitch3_Triggered, LimitSwitch3_Released, 50);
}

void EXTI9_5_IRQHandler(void) {
    static uint32_t debounce_time_7 = 0;
    static uint32_t debounce_time_6 = 0;

    Handle_EXTI_Interrupt(GPIOF, GPIO_PIN_7, &debounce_time_7,
                          LimitSwitch2_Triggered, LimitSwitch2_Released, 50);

    Handle_EXTI_Interrupt(GPIOH, GPIO_PIN_6, &debounce_time_6,
                          LimitSwitch4_Triggered, LimitSwitch4_Released, 50);
}

void LimitSwitch1_Triggered(void) {
	printf("Limit Switch 1 Pressed\n");
}

void LimitSwitch2_Triggered(void) {
	printf("Limit Switch 2 Pressed\n");
}

void LimitSwitch3_Triggered(void) {
	printf("Limit Switch 3 Pressed\n");
}

void LimitSwitch4_Triggered(void) {
	printf("Limit Switch 4 Pressed\n");
}

void LimitSwitch1_Released(void) {
	printf("Limit Switch 1 Released\n");
}

void LimitSwitch2_Released(void) {
	printf("Limit Switch 2 Released\n");
}

void LimitSwitch3_Released(void) {
	printf("Limit Switch 3 Released\n");
}

void LimitSwitch4_Released(void) {
	printf("Limit Switch 4 Released\n");
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
