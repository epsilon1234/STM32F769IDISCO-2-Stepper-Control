import serial
import struct
import time
from datetime import datetime

# Configuration
UART_PORT = 'COM10'  
BAUD_RATE = 115200 

ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)

def calculate_checksum(data):
    """Calculate XOR checksum for the data bytes."""
    checksum = 0
    for byte in data:
        checksum ^= byte
    return checksum

def send_telecommand(direction1, steps1, direction2, steps2, speed):
    """Send telecommand to STM32."""
    header = 0xAA
    end_byte = 0x55
    
    # Create telecommand message
    message = struct.pack(
        '>B B I B I H',  # Format: header, dir1, steps1, dir2, steps2, speed
        header,
        direction1,
        steps1,
        direction2,
        steps2,
        speed
    )
    checksum = calculate_checksum(message)
    message += struct.pack('B', checksum) + struct.pack('B', end_byte)
    
    # Transmit the message
    ser.write(message)
    print(f"Sent: {message.hex()}")

def  log_to_file(log_data):
   log_file = open(f'D:/VS CODE/E Band Tracker/January 2025/01-01-2025/Changes/log.txt', 'a')
   timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
   log_line = f"[{timestamp}] {log_data}\n"
   log_file.write(log_line)

def receive_telemetry():
    while True:
        if ser.in_waiting >= 9:  # Telemetry message length is 9 bytes
            telemetry_data = ser.read(9)
            print(telemetry_data)
            if telemetry_data[0] == 0xBB and telemetry_data[-1] == 0xEE:
                motor_id = telemetry_data[1]
                status = telemetry_data[2]
                current_steps = struct.unpack('>I', telemetry_data[3:7])[0]
                checksum = telemetry_data[7]
                calculated_checksum = calculate_checksum(telemetry_data[:-2])
                
                if checksum == calculated_checksum:
                    print(f"Telemetry Received - Motor {motor_id}:")
                    print(f"  Status: {status}")
                    print(f"  Current Steps: {current_steps}")
                    log_to_file(f'Motor {motor_id}, Dir {status}, Current Steps {current_steps}')
                else:
                    print("Checksum mismatch in telemetry!")
            else:
                print("Invalid telemetry message!")


if __name__ == "__main__":
    try:
        while True:
            direction1 = 1  # CW
            steps1 = 100
            direction2 = 1  # CCW
            steps2 = 100
            speed = 10000  # 10 kHz
            
            send_telecommand(direction1, steps1, direction2, steps2, speed)
            time.sleep(1)  

            receive_telemetry()
    except KeyboardInterrupt:
        print("Terminating...")
    finally:
        ser.close()



