/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f7xx.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
void stepper_init(void);
void stepper1_start(uint16_t Pulse, uint8_t DIR);
void stepper2_start(uint16_t Pulse, uint8_t DIR);
void stepper_stop_motor1(void);
void stepper_stop_motor2(void);
void stepper_finish(void);
void accelerate(uint8_t timer_id, uint16_t start_freq, uint16_t end_freq, uint32_t duration);
void decelerate(uint8_t timer_id, uint16_t start_freq, uint16_t end_freq, uint32_t duration);
void stepper_set_frequency(uint16_t new_freq, uint8_t timer_id);
void update_stepper_speed(uint8_t stepper, uint32_t speed);
void delay_ms(uint32_t ms);
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define AF02 0x02
#define __DIR_CW 1
#define __DIR_CCW 0
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint16_t start_freq = 2000;     // Example start frequency (Hz)
uint16_t end_freq = 20000;       // Example end frequency (Hz)
uint32_t acc_duration = 1000;   // Example acceleration duration (ms)
uint32_t dec_duration = 1000;   // Example deceleration duration (ms)
uint8_t DIR=0;
volatile uint32_t systick_counter = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
//	  GPIO_LimitSwitch_Init();  // Initialize GPIO for limit switches
  stepper_init();           // Initialize stepper motors

  uint32_t target_pulses1 = 32000;  // Total pulses for Stepper 1
  uint32_t target_pulses2 = 32000;  // Total pulses for Stepper 2
  uint32_t accel_pulses = 1000;     // Pulses for acceleration
  uint32_t decel_pulses = 1000;     // Pulses for deceleration

  uint32_t current_pulses1 = 0;    // Completed pulses for Stepper 1
  uint32_t current_pulses2 = 0;    // Completed pulses for Stepper 2
  uint32_t speed1 = 1000;          // Initial speed for Stepper 1 (in Hz)
  uint32_t speed2 = 1000;          // Initial speed for Stepper 2 (in Hz)
  uint32_t max_speed = 30000;       // Maximum speed for both steppers (in Hz)
//Max speed 20000 = 10kHz
//Max speed 30000 = 14-16kHz
  stepper1_start(target_pulses1, 1);  // Start Stepper 1
  stepper2_start(target_pulses2, 0);  // Start Stepper 2
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	/* Read current pulses */
	current_pulses1 = target_pulses1 - TIM1->CNT;  // Assuming TIM1->CNT decreases for Stepper 1
	current_pulses2 = target_pulses2 - TIM2->CNT;  // Assuming TIM2->CNT decreases for Stepper 2

	/* Stepper 1: Acceleration and Deceleration */
	if (current_pulses1 < accel_pulses)
	{
	  speed1 = 1000 + (max_speed - 1000) * current_pulses1 / accel_pulses;
	}
	else if (current_pulses1 > (target_pulses1 - decel_pulses))
	{
	  uint32_t decel_index1 = target_pulses1 - current_pulses1;
	  speed1 = 1000 + (max_speed - 1000) * decel_index1 / decel_pulses;
	}
	else
	{
	  speed1 = max_speed;
	}
	update_stepper_speed(1, speed1);

	/* Stepper 2: Acceleration and Deceleration */
	if (current_pulses2 < accel_pulses)
	{
	  speed2 = 1000 + (max_speed - 1000) * current_pulses2 / accel_pulses;
	}
	else if (current_pulses2 > (target_pulses2 - decel_pulses))
	{
	  uint32_t decel_index2 = target_pulses2 - current_pulses2;
	  speed2 = 1000 + (max_speed - 1000) * decel_index2 / decel_pulses;
	}
	else
	{
	  speed2 = max_speed;
	}
	update_stepper_speed(2, speed2);

	/* Optional: Log current speeds */
//	printf("Stepper 1: Current pulses: %lu, Speed: %lu Hz\n", current_pulses1, speed1);
//	printf("Stepper 2: Current pulses: %lu, Speed: %lu Hz\n", current_pulses2, speed2);

//	delay_ms(10);  // Non-blocking delay using SysTick
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 216;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void update_stepper_speed(uint8_t stepper, uint32_t speed)
{
    // Assuming a 108 MHz clock
    uint32_t system_clock = 108000000U;
    uint32_t prescaler = (system_clock / speed) - 1;

    // If prescaler is 0, set to a default value like 3000
    if (prescaler == 0) {
        prescaler = 3000;
    }

    // Ensure the prescaler is within the valid range (max prescaler is 65535)
    if (prescaler > 65535) {
        prescaler = 65535;  // Set to max if it's too large
    }

    if (stepper == 1)
    {
        TIM3->PSC = prescaler;     // Set prescaler for Stepper 1 (PWM generation on TIM3)
//        TIM3->EGR = TIM_EGR_UG;    // Trigger an update event for TIM3
    }
    else if (stepper == 2)
    {
        TIM4->PSC = prescaler;     // Set prescaler for Stepper 2 (PWM generation on TIM4)
//        TIM4->EGR = TIM_EGR_UG;    // Trigger an update event for TIM4
    }
}



void stepper1_stop(void) {
    TIM3->CR1 &= ~TIM_CR1_CEN;
}

void stepper2_stop(void) {
    TIM4->CR1 &= ~TIM_CR1_CEN;
}

void stepper_set_frequency(uint16_t new_freq, uint8_t timer_id) {
    // Timer IDs 1 for TIM3, 2 for TIM4
    if (timer_id == 1) {
        // Adjust TIM3 frequency by changing PSC and ARR
        TIM3->ARR = new_freq;
    } else if (timer_id == 2) {
        // Adjust TIM4 frequency by changing PSC and ARR
        TIM4->ARR = new_freq;
    }
}

void accelerate(uint8_t timer_id, uint16_t start_freq, uint16_t end_freq, uint32_t duration) {
    // Linear acceleration from start_freq to end_freq over a given duration
    uint16_t freq_step = (end_freq - start_freq) / duration;
    uint32_t time = 0;

    for (time = 0; time < duration; time++) {
        uint16_t current_freq = start_freq + time * freq_step;
        stepper_set_frequency(current_freq, timer_id);
        HAL_Delay(1);  // Adjust delay based on desired acceleration rate
    }
}

void decelerate(uint8_t timer_id, uint16_t start_freq, uint16_t end_freq, uint32_t duration) {
    // Linear deceleration from start_freq to end_freq over a given duration
    uint16_t freq_step = (start_freq - end_freq) / duration;
    uint32_t time = 0;

    for (time = 0; time < duration; time++) {
        uint16_t current_freq = start_freq - time * freq_step;
        stepper_set_frequency(current_freq, timer_id);
        HAL_Delay(1);  // Adjust delay based on desired deceleration rate
    }
}

void stepper1_start(uint16_t Pulse, uint8_t DIR) {
    uint8_t Q = Pulse / 65536;
    uint16_t R = Pulse % 65536;

    TIM1->DIER &= ~TIM_DIER_UIE;

    if (R == 0) {
        R = 65536;
        Q = Q - 1;
    }

    TIM1->RCR = Q;
    TIM1->EGR = TIM_EGR_UG;
    TIM1->CNT = R + 1;
    TIM1->SR = ~TIM_SR_UIF;
    TIM1->DIER |= TIM_DIER_UIE;

    TIM3->CR1 |= TIM_CR1_CEN;
    TIM1->CR1 |= TIM_CR1_CEN;
    // Accelerate TIM3 (for stepper1)
//    accelerate(1, TIM3->ARR, acc_freq, acc_duration);

    // Decelerate TIM3 after some operation (if needed)
//    decelerate(1, TIM3->ARR, dec_freq, dec_duration);
}

void stepper2_start(uint16_t Pulse, uint8_t DIR) {
    uint8_t Q = Pulse / 65536;
    uint16_t R = Pulse % 65536;

    TIM2->DIER &= ~TIM_DIER_UIE;

    if (R == 0) {
        R = 65536;
        Q = Q - 1;
    }

    TIM2->RCR = Q;
    TIM2->EGR = TIM_EGR_UG;
    TIM2->CNT = R + 1;
    TIM2->SR = ~TIM_SR_UIF;
    TIM2->DIER |= TIM_DIER_UIE;

    TIM4->CR1 |= TIM_CR1_CEN;
    TIM2->CR1 |= TIM_CR1_CEN;

    // Accelerate TIM4 (for stepper2)
//    accelerate(2, TIM4->ARR, acc_freq, acc_duration);
    // Decelerate TIM4 after some operation (if needed)
//    decelerate(2, TIM4->ARR, dec_freq, dec_duration);
}

void stepper1_finish(void) {
    stepper1_stop();
}

void stepper2_finish(void) {
    stepper2_stop();
}


void stepper_init(void) {
    // Enable GPIOB clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    // Enable GPIOB clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

    // Configure PA6 as alternate function (AF02 for TIM3_CH1)
    GPIOA->MODER &= ~GPIO_MODER_MODER6;  // Clear mode bits for PA6
    GPIOA->MODER |= GPIO_MODER_MODER6_1; // Set to alternate function mode
    GPIOA->AFR[0] |= (AF02 << (4 * 6));  // Set AF02 for PA6 (TIM3_CH1)

    // Configure PB8 as alternate function (AF02 for TIM4_CH3)
    GPIOB->MODER &= ~GPIO_MODER_MODER8;
    GPIOB->MODER |= GPIO_MODER_MODER8_1; // Alternate function mode
    GPIOB->AFR[1] |= (AF02 << ((8 - 8) * 4)); // AF02 for TIM4_CH3

    // Enable TIM3 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // Enable TIM4 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

    // Reset and configure TIM3
    TIM3->CR1 = 0x00;              // Reset control register
    TIM3->PSC = 3000U;            // Prescaler for desired frequency
    TIM3->ARR = 1U;                // Auto-reload value
    TIM3->CCR1 = 1U;               // 50% duty cycle for PWM

    // Reset and configure TIM4
    TIM4->CR1 = 0x00;              // Reset control register
    TIM4->PSC = 3000U;             // Prescaler for desired frequency
    TIM4->ARR = 1U;             // Auto-reload value
    TIM4->CCR3 = 1U;             // 50% duty cycle for PWM

    // Configure TIM3 Channel 1 as PWM mode 1
    TIM3->CCMR1 &= ~TIM_CCMR1_CC1S; // Clear input capture bits
    TIM3->CCMR1 |= TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2; // Set PWM mode 1
    TIM3->CCMR1 |= TIM_CCMR1_OC1PE; // Enable output preload

    // Configure TIM4 Channel 3 as PWM mode 1
    TIM4->CCMR2 &= ~TIM_CCMR2_CC3S; // Clear input capture bits
    TIM4->CCMR2 |= TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3M_2; // Set PWM mode 1
    TIM4->CCMR2 |= TIM_CCMR2_OC3PE; // Enable output preload

    // Enable TIM3 Channel 1 output
    TIM3->CCER &= ~TIM_CCER_CC1P;  // Active high polarity
    TIM3->CCER |= TIM_CCER_CC1E;   // Enable output

    // Enable TIM4 Channel 3 output
    TIM4->CCER &= ~TIM_CCER_CC3P;  // Active high polarity
    TIM4->CCER |= TIM_CCER_CC3E;   // Enable output

    // TIM1 Init
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    TIM1->CR1 &= ~TIM_CR1_CMS;

    //TIM2 Init
    RCC->APB1ENR |=RCC_APB1ENR_TIM2EN;

    TIM2->CR1 &= ~TIM_CR1_CMS;

    // Enable the TIM1 clock in APB2
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Enable the TIM1 clock in APB2
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    // Configure counter mode for TIM1: Edge-aligned, up-counting, one-pulse mode
    TIM1->CR1 &= ~TIM_CR1_CMS;          // Clear CMS bits (edge-aligned mode)
    TIM1->CR1 |= TIM_CR1_DIR;           // Set DIR for down-counting
    TIM1->CR1 |= TIM_CR1_OPM;           // Enable one-pulse mode

    // Configure counter mode for TIM2: Edge-aligned, up-counting, one-pulse mode
    TIM2->CR1 &= ~TIM_CR1_CMS;          // Clear CMS bits (edge-aligned mode)
    TIM2->CR1 |= TIM_CR1_DIR;           // Set DIR for down-counting
    TIM2->CR1 |= TIM_CR1_OPM;           // Enable one-pulse mode

    // Set TIM1 prescaler and auto-reload value
    TIM1->PSC = 0;                      // No prescaler
    TIM1->ARR = 65535;                  // Set auto-reload value to maximum

    // Set TIM2 prescaler and auto-reload value
    TIM2->PSC = 0;                      // No prescaler
    TIM2->ARR = 65535;                  // Set auto-reload value to maximum

    // Configure TIM3 as the master mode trigger
    TIM3->CR2 &= ~TIM_CR2_MMS;          // Clear MMS bits
    TIM3->CR2 |= TIM_CR2_MMS_1;         // Set update event as TRGO (Master Mode Selection)

    // Configure TIM4 as the master mode trigger
    TIM4->CR2 &= ~TIM_CR2_MMS;          // Clear MMS bits
    TIM4->CR2 |= TIM_CR2_MMS_1;         // Set update event as TRGO (Master Mode Selection)

    // Configure TIM1 as a slave, triggered by TIM3
    TIM1->SMCR &= ~TIM_SMCR_TS;         // Clear TS bits
    TIM1->SMCR |= TIM_SMCR_TS_1 ; // Set ITR2 (TIM3 trigger) as the trigger input
    TIM1->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_1 | TIM_SMCR_SMS_0); // Configure SMS for trigger mode

    // Configure TIM2 as a slave, triggered by TIM4
    TIM2->SMCR &= ~TIM_SMCR_TS;         // Clear TS bits
    TIM2->SMCR |= (TIM_SMCR_TS_1|TIM_SMCR_TS_0) ; // Set ITR3 (TIM2 trigger) as the trigger input
    TIM2->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_1 | TIM_SMCR_SMS_0); // Configure SMS for trigger mode

    // Second Master (T1) and Slave (T3) relationship

    // TIM1 Master TGRO
    TIM1->CR2 &= ~TIM_CR2_MMS;
    TIM1->CR2 |= TIM_CR2_MMS_0;


    // TIM2 Master TGRO
    TIM2->CR2 &= ~TIM_CR2_MMS;
    TIM2->CR2 |= TIM_CR2_MMS_0;

    // TIM3 Slave Trigger from TIM1 ITR0
    TIM3->SMCR &= ~TIM_SMCR_TS;

    //TIM4 Slave Trigger from TIM2 ITR1
    TIM4->SMCR &= ~TIM_SMCR_TS;
    TIM4->SMCR |= TIM_SMCR_TS_0;

    // TIM3 Slave Gated mode SMS
    TIM3->SMCR &= ~TIM_SMCR_SMS;
    TIM3->SMCR |= (TIM_SMCR_SMS_2 | TIM_SMCR_SMS_0);

    //TIM4 Slave Gated mode SMS
    TIM4->SMCR &=~TIM_SMCR_SMS;
    TIM4->SMCR |= (TIM_SMCR_SMS_2|TIM_SMCR_SMS_0);

    // TIM1 update interrupt
    TIM1->SR = ~TIM_SR_UIF;
    TIM1->DIER |= TIM_DIER_UIE;

    //TIM2 update interrupt
    TIM2->SR = ~TIM_SR_UIF;
    TIM2->DIER |= TIM_DIER_UIE;

    NVIC_SetPriority(TIM1_UP_TIM10_IRQn, NVIC_EncodePriority(0, 9, 0));
    NVIC_EnableIRQ(TIM1_UP_TIM10_IRQn);
    NVIC_SetPriority(TIM2_IRQn, NVIC_EncodePriority(0, 9, 0));
    NVIC_EnableIRQ(TIM2_IRQn);
}


void TIM1_UP_TIM10_IRQHandler(void) {
    if (TIM1->SR & TIM_SR_UIF) {
        TIM1->SR &= ~TIM_SR_UIF;
        stepper1_finish();
    }
}

void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR &= ~TIM_SR_UIF;
        stepper2_finish();
    }
}
__weak void SysTick_Handler(void)
{
  HAL_IncTick();      // Increment HAL's tick (for compatibility)
  systick_counter++;  // Increment custom counter
}

/* Function to implement non-blocking delay */
void delay_ms(uint32_t ms)
{
  uint32_t start_time = systick_counter;
  while ((systick_counter - start_time) < ms)
  {
    // Wait for the desired duration
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
