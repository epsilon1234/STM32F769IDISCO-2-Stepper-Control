import serial
import struct
import time
from datetime import datetime

UART_PORT = 'COM10'  
BAUD_RATE = 115200 

ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)

def calculate_checksum(data):
    checksum = 0
    for byte in data:
        checksum ^= byte
    return checksum

def send_telecommand(direction1, steps1, direction2, steps2, speed):
    header = 0xAA
    end_byte = 0x55
    
    message = struct.pack(
        '>B B I B I H',  # Format: header, dir1, steps1, dir2, steps2, speed
        header,
        direction1,
        steps1,
        direction2,
        steps2,
        speed
    )
    checksum = calculate_checksum(message)
    message += struct.pack('B', checksum) + struct.pack('B', end_byte)

    ser.write(message)
    print(f"Sent: {message.hex()}")

def  log_to_file(log_data):
   log_file = open(f'D:/VS CODE/E Band Tracker/January 2025/03-01-2025/log.txt', 'a')
   timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
   log_line = f"[{timestamp}] {log_data}\n"
   log_file.write(log_line)

def receive_telemetry():
    buffer = b""  
    while True:
        if ser.in_waiting > 0:
            buffer += ser.read(ser.in_waiting) 
            while len(buffer) >= 11:  
                start_index = buffer.find(0xBB)  
                if start_index == -1:
                    buffer = b""
                    break
                
                buffer = buffer[start_index:]
                if len(buffer) < 11: 
                    break
                
                if buffer[10] == 0xEE:  
                    telemetry_data = buffer[:11]  
                    buffer = buffer[11:]  
                    
                    motor_id = telemetry_data[1]
                    direction = telemetry_data[2]
                    current_steps = struct.unpack('>I', telemetry_data[3:7])[0]
                    status1 = telemetry_data[7]  # Status of stepper 1
                    status2 = telemetry_data[8]  # Status of stepper 2
                    checksum = telemetry_data[9]
                    calculated_checksum = calculate_checksum(telemetry_data[:-2])
                    
                    if checksum == calculated_checksum:
                        print(f"Telemetry Received - Motor {motor_id}:")
                        print(f"  Direction: {direction}")
                        print(f"  Current Steps: {current_steps}")
                        print(f"  Status 1 (Stepper 1): {'Running' if status1 else 'Stopped'}")
                        print(f"  Status 2 (Stepper 2): {'Running' if status2 else 'Stopped'}")
                        log_to_file(f'Motor {motor_id}, Dir {direction}, Steps {current_steps}, Status1 {status1}, Status2 {status2}')
                    else:
                        print("Checksum mismatch in telemetry!")
                else:
                    buffer = buffer[1:]  # Shift buffer to find the next valid packet

if __name__ == "__main__":
    try:
        while True:
            direction1 = 1  # CW
            steps1 = 32000
            direction2 = 1  # CCW
            steps2 = 32000
            speed = 10000  # 10 kHz
            
            send_telecommand(direction1, steps1, direction2, steps2, speed)
            time.sleep(1)  

            receive_telemetry()
    except KeyboardInterrupt:
        print("Terminating...")
    finally:
        ser.close()

