import serial
import struct
import time
from datetime import datetime

UART_PORT = 'COM10'  
BAUD_RATE = 115200 

ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=0.1)

command_running = 0

def calculate_checksum(data):
    checksum = 0
    for byte in data:
        checksum ^= byte
    return checksum

def send_telecommand(direction1, steps1, direction2, steps2, speed):
    header = 0xAA
    end_byte = 0x55
    
    message = struct.pack(
        '>B B I B I H',  # Format: header, dir1, steps1, dir2, steps2, speed
        header,
        direction1,
        steps1,
        direction2,
        steps2,
        speed
    )
    checksum = calculate_checksum(message)
    message += struct.pack('B', checksum) + struct.pack('B', end_byte)

    ser.write(message)
    print(f"Sent: {message.hex()}")

def  log_to_file(log_data):
   log_file = open(f'D:/VS CODE/E Band Tracker/January 2025/28-01-2025/log.txt', 'a')
   timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
   log_line = f"[{timestamp}] {log_data}\n"
   log_file.write(log_line)

def receive_telemetry():
    buffer = b""
    global command_running
    while command_running:
        if ser.in_waiting > 0:
            buffer += ser.read(ser.in_waiting)
            while len(buffer) >= 11:
                start_index = buffer.find(0xBB)
                if start_index == -1:
                    buffer = buffer[-10:] 
                    break
                
                buffer = buffer[start_index:]
                if len(buffer) < 11:
                    break
                
                if buffer[10] == 0xEE:  
                    telemetry_data = buffer[:11]
                    buffer = buffer[11:]
                    
                    motor_id = telemetry_data[1]
                    direction = telemetry_data[2]
                    current_steps = struct.unpack('>I', telemetry_data[3:7])[0]
                    if current_steps >= 4000000000:
                        current_steps = 0
                    status1 = telemetry_data[7]
                    status2 = telemetry_data[8]
                    checksum = telemetry_data[9]
                    calculated_checksum = calculate_checksum(telemetry_data[:-2])
                    
                    if checksum == calculated_checksum:
                        log_to_file(f'Motor {motor_id}, Dir {direction}, Steps {current_steps}, Status1 {status1}, Status2 {status2}')
                        
                        if not status1 and not status2:
                            print("Steps Reached")
                            command_running = 0
                            break
                    else:
                        print("Checksum mismatch in telemetry!")
                        print(f"Actual: {checksum}, Calculated: {calculated_checksum}")
                else:
                    buffer = buffer[1:]
                
        time.sleep(0.01)

def ask_input():
    motor1_dir=input("Enter motor 1 direction: ")
    motor2_dir=input("Enter motor 2 direction: ")
    motor1_steps=input("Enter motor 1 steps: ")
    motor2_steps=input("Enter motor 2 steps: ")
    direction1 = int(motor1_dir)  # CW
    steps1 = int(motor1_steps)
    direction2 = int(motor2_dir)  # CCW
    steps2 = int(motor2_steps)
    speed = 10000  # 10 kHz
    
    send_telecommand(direction1, steps1, direction2, steps2, speed)



if __name__ == "__main__":
    try:
        while True:
        # direction1 = 1  # CW
        # steps1 = 32000
        # direction2 = 1  # CCW
        # steps2 = 32000
        # speed = 10000  # 10 kHz
        
        # send_telecommand(direction1, steps1, direction2, steps2, speed)
            ask_input()
            time.sleep(1)  
            command_running=1
            receive_telemetry()
            command_running=0
    except KeyboardInterrupt:
        print("Terminating...")
    finally:
        ser.close()

